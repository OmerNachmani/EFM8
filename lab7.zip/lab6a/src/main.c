#include <SI_EFM8UB2_Register_Enums.h>
#include "InitDevice.h"
#include <stdint.h>
#include "tick.h"

// --- CONSTANTS ---
#define PWM_STEP       25    // ~10% of 255
#define JOY_LEFT_MIN   550   // ~1.8V
#define JOY_LEFT_MAX   680   // ~2.2V
#define JOY_RIGHT_MIN  740   // ~2.3V
#define JOY_RIGHT_MAX  850   // ~2.7V

// --- PIN DEFINITIONS ---
SI_SBIT(M1,      SFR_P0, 4);
SI_SBIT(M2,      SFR_P0, 5);
SI_SBIT(BTN0,    SFR_P0, 2);
SI_SBIT(BTN1,    SFR_P0, 3);

// --- HARDWARE OVERRIDE ---
void Manual_Override(void)
{
    // 1. Force Crossbar to Route PWM to P1.1
    P0SKIP = 0xFF; // Skip Port 0
    P1SKIP = 0x01; // Skip P1.0
    XBR1   = 0x41; // Enable Crossbar + PCA CEX0

    // 2. Fix Port Modes
    P1MDOUT |= 0x02;  // P1.1 (PWM) to Push-Pull
    P2MDIN  &= ~0x20; // P2.5 (Joystick) to Analog Mode
    P2      |= 0x20;  // Latch high for Analog path

    // 3. Fix ADC Channel (P2.5 is ADC0.13)
    AMX0P = 0x0D;

    // 4. Force PCA Channel 0 into 8-bit PWM mode
    PCA0CPM0 = 0x42;
}

void SiLabs_Startup (void) { PCA0MD &= ~0x40; }

uint16_t Read_Joystick(void)
{
    ADC0CN0_ADINT = 0;
    ADC0CN0_ADBUSY = 1;
    while (!ADC0CN0_ADINT);
    return ADC0;
}

void main (void)
{
    uint16_t joy_val;
    int16_t current_pwm = 0;

    enter_DefaultMode_from_RESET(); // Runs auto-generated code
    Manual_Override();              // Overwrites the mistakes
    IE_EA = 1;

    M1 = 0; M2 = 0;
    PCA0CPH0 = 0;

    while (1)
    {
        joy_val = Read_Joystick();

        // --- JOYSTICK STEP LOGIC ---
        if (joy_val > JOY_RIGHT_MIN && joy_val < JOY_RIGHT_MAX)
        {
            current_pwm += PWM_STEP;
            if (current_pwm > 255) current_pwm = 255;
            PCA0CPH0 = (uint8_t)current_pwm;
            Wait(200); // 200ms step delay
        }
        else if (joy_val > JOY_LEFT_MIN && joy_val < JOY_LEFT_MAX)
        {
            current_pwm -= PWM_STEP;
            if (current_pwm < 0) current_pwm = 0;
            PCA0CPH0 = (uint8_t)current_pwm;
            Wait(200); // 200ms step delay
        }

        // --- BUTTON DIRECTION CONTROL ---
        if (BTN0 == 0) // Spin Right
        {
            if (M2 == 1) { M1 = 0; M2 = 0; Wait(200); }
            M1 = 1; M2 = 0;
        }
        if (BTN1 == 0) // Spin Left
        {
            if (M1 == 1) { M1 = 0; M2 = 0; Wait(200); }
            M1 = 0; M2 = 1;
        }
    }
}
